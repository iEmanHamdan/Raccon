from fastapi import APIRouter, Depends
from services.event_service import EventService
from models.user import User
from api.auth.dependencies import get_current_user
from api.events.schemas import EventBase, EventDetailResponse, EventTagConfigView, EventUpdateRequest, EventCreateRequest, EventResponse, EventSetupRequest
import uuid
from typing import List


router = APIRouter(prefix="/events", tags=["Events"])

@router.get("/{event_id}", response_model=EventDetailResponse)
def get_event_details(
    event_id: uuid.UUID,
    service: EventService = Depends(),
    current_user: User = Depends(get_current_user)
):
    return service.get_event_details(current_user, event_id)

@router.put("/{event_id}/setup")
def setup_event_journey(
    event_id: uuid.UUID,
    request: EventSetupRequest,
    service: EventService = Depends(),
    current_user: User = Depends(get_current_user)
):
    service.setup_event_journey(current_user, event_id, request)
    return {"status": "success", "message": "Tag setup saved successfully."}


@router.patch("/{event_id}", response_model=EventResponse)
def update_event(
    event_id: uuid.UUID,
    request: EventUpdateRequest,
    service: EventService = Depends(),
    current_user: User = Depends(get_current_user)
):
    return service.update_event(current_user, event_id, request.model_dump())


@router.get("", response_model=List[EventBase])
def list_my_events(
    service: EventService = Depends(),
    current_user: User = Depends(get_current_user)
):
    return service.list_my_events(current_user)